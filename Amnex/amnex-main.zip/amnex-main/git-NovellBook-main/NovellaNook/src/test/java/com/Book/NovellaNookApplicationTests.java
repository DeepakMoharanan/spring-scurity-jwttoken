package com.Book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovellaNookApplicationTests {

	@Test
	void contextLoads() {
	}

}
