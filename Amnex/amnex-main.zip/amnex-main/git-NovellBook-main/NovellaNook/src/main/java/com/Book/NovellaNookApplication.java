package com.Book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NovellaNookApplication {

	public static void main(String[] args) {
		SpringApplication.run(NovellaNookApplication.class, args);
	}

}
